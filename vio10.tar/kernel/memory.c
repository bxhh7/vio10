#include <x86.h>
#include <libc/libc.h>
#include <util.h>
#include <memory.h>

extern u32 istack_top;

/* We'll be using the Intel flat memory model to simply ignore segmentation,
 * we're gonna need the segments KERNEL_CODE, KERNEL_DATA, USER_CODE, USER_DATA */
segment_descriptor_t GDT[6];
tss_t TSS; /* we'll only use one TSS for the whole system */
pmm_t pmm;
pte_t** kernel_pgdir;
extern char kernel_text_end[];
extern char kernel_data_end[];
extern char kernel_end[];
extern char kernel_begin[];
/* convinent function for making (flat mode)segment descriptors, only the low 20 bits of limit
 * are used and only the low 4 bits of flags are used.*/
segment_descriptor_t make_segment(u32 base, u32 limit, u8 access, u8 flags) {
	segment_descriptor_t segdesc; 
	segdesc.limit_low16 = limit & 0xffff;
	segdesc.limit_high4 = (limit >> 16) & 0xf;
	
	segdesc.base_low16  = base & 0xffff;
	segdesc.base_mid8   = (base >> 16) & 0xff;
	segdesc.base_high8  = (base >> 24 ) & 0xff;
	
	segdesc.access = access;
	segdesc.flag_reserved = 0;
	segdesc.flag_L = (flags >> 1) & 0x1;
	segdesc.flag_DB =  (flags >> 2) & 0x1;  
	segdesc.flag_G  = (flags >> 3) & 0x1;
	return segdesc; 
}


void init_segmentation() {
	GDT[SEG_NULL]  = make_segment(0, 0, 0, 0); 
	GDT[SEG_KCODE] = make_segment(0, 0xFFFFF, 0x9A, 0xC);
	GDT[SEG_KDATA] = make_segment(0, 0xFFFFF, 0x92, 0xC);
	GDT[SEG_UDATA] = make_segment(0, 0xFFFFF, 0xF2, 0xC);
	GDT[SEG_UCODE] = make_segment(0, 0xFFFFF, 0xFA, 0xC);
	/* TODO, fix this, this is only for debugging purposes */
	memset(&TSS, 0, sizeof(TSS));
	TSS.esp0 = (u32)&istack_top;
	TSS.ss0 = SEG_KDATA * 8;
	GDT[SEG_TSS]   = make_segment((u32)&TSS, sizeof(TSS), 0x89, 0x0);
	
	lgdt(GDT, sizeof(GDT));
	flush_gdt();
	flush_tss();
}
u32 page_roundup(u32 x) {
	if (x % PAGE_SIZE == 0)
		return x;
	x += PAGE_SIZE;
	x = x & ~(PAGE_SIZE-1);
	return x;
}
u32 page_rounddown(u32 x) {
	if (x % PAGE_SIZE == 0)
		return x;
	x = x & ~(PAGE_SIZE-1);
	return x;
}


void pmm_init(u8* start, u8* end) {
	start = (u8*)page_roundup((u32)start);
	pmm.freelist = NULL;

	if (((u32)start % PAGE_SIZE) != 0) {
		panic("pmm_init(): start=%x is not page-aligned.\n", start);
	}
	for (u8* i = start; i < end; i += PAGE_SIZE) {
		pmm.free_pages++;	
		struct freelist_t* new_head = (struct freelist_t*)i;
		new_head->next = pmm.freelist;
		pmm.freelist = new_head;
		
		pmm.end = i;
	}
	pmm.start = start;
	pmm.allocated_pages = 0;
	kdebug("pmm_init(): initialized pmm with start=%x, end = %x, free_pages = %d\n", pmm.start, pmm.end, pmm.free_pages);
}
void* pmm_alloc() {
	kdebug("pmm_alloc(): free_pages = %d, allocated_pages = %d ", pmm.free_pages, pmm.allocated_pages);
	if (pmm.free_pages <= 0) {
		kdebug("OOM");
		return NULL;
	}
	void* ret = pmm.freelist;
	pmm.freelist = pmm.freelist->next;
	pmm.free_pages--;
	pmm.allocated_pages++;
	kdebug("pmm_alloc(): returning %x\n", (u32)ret);
	return ret;
}
void pmm_free(void *ptr) {
	kdebug("pmm_free(): free_pages = %d, allocated_pages = %d ", pmm.free_pages, pmm.allocated_pages);
	kdebug("pmm_free(): freeing %x\n", (u32)ptr);
	struct freelist_t* p = (struct freelist_t*)ptr;
	p->next = pmm.freelist;
	pmm.freelist = p;
	pmm.allocated_pages--;
	pmm.free_pages++;
}
pte_t** vmm_setup_kernel() { /* allocates a PD, identity maps the kernel and returns it */ 
	pte_t** ret = pmm_alloc();
	memset(ret, 0, PAGE_SIZE);
	/* TODO: don't map the [kernel_text_begin:kernel_text_end] section as writeable */
	vmm_map(ret, 0x0, 0x0, (u32)kernel_end - 0x0, PTE_W | PTE_P);
	return ret;
}

void vmm_setup_kpgdir() {
	/* TODO: this parts should be modified later when multi-processor is enabled */
	kernel_pgdir = vmm_setup_kernel();
	load_cr3(kernel_pgdir);
}
int pte_is_empty(pte_t x) {
	if (x.flags == 0 && x.addr_12_31 == 0)
		return 1;
	return 0;
}
void print_pdir(pte_t ** pdir) {
	for (int pdir_index = 0; pdir_index < 1024; pdir_index++) {
		if (pdir[pdir_index] == 0x0)
			continue;
		for (int ptable_index = 0; ptable_index < 1024; ptable_index++) {
			if (pte_is_empty(pdir[pdir_index][ptable_index])) 
				continue;
			kdebug("pdir[%d][%d] = (%x, %x) => ", pdir_index, ptable_index, 
					pdir[pdir_index][ptable_index].addr_12_31, 
					pdir[pdir_index][ptable_index].flags);
			kdebug("physical addr %x to virtual addr %x\n", pdir[pdir_index][ptable_index].addr_12_31,
					VADDR(pdir_index, ptable_index, 0));
		}
	}
}
void vmm_map(pte_t** pdir, void* phys_start, void* virtual_start, u32 size, u8 perms) {
	/* TODO check for remaps(pte.flag_bits.present) */	
	u32 end = page_roundup((u32)(virtual_start + size));
	u32 phys = page_roundup((u32) phys_start);
	for (u32 i = (u32)virtual_start; i < end; i += PAGE_SIZE) {
		u32 pde_index = VADDR_PDE_INDEX(i);
		u32 pte_index = VADDR_PTE_INDEX(i);
		//u16 offset = VADDR_OFFSET(virtual_start);
		if (pdir[pde_index] == 0)
			pdir[pde_index] = pmm_alloc();
		pdir[pde_index][pte_index].addr_12_31 = phys & 0xfffff; 
		pdir[pde_index][pte_index].flags = perms;
		phys += PAGE_SIZE;
	}

	kdebug("vmm_map(): pdir = %x:\n", pdir);
	//print_pdir(pdir);
}

