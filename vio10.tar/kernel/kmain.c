#include <boot/multiboot.h>
#include <memory.h>
#include <interrupts.h>
#include<libc/libc.h>
#include <uart.h>
#include <util.h>
extern char kernel_text_end[];
extern char kernel_data_end[];
extern char kernel_end[];
extern char kernel_begin[];
char buf[0x100000];
void func(char a[]) {}

int kmain(multiboot_info_t* minfo) {
	char *vidmem = (char*) 0xb8000;
	
	func(kernel_text_end);
	func(kernel_data_end);
	func(kernel_end);
	func(kernel_begin);

	char *str = "hi, we in kernel.\r\n";
	int index = 0;
	char *ptr = str;
	for (int i = 0; i < 80*26; i++)
		vidmem[i] = ' ';
	while (*ptr != '\0') {
		vidmem[index] = *ptr;
		ptr++;
		index += 2;
	}
	cli();
	init_segmentation();
	init_interrupts();
	sti();
	asm volatile("int $111");
	asm volatile("int $40");
	asm volatile("int $113");
	asm volatile("int $114");
	asm volatile("int $34");	
	uart_init(COM1, 115200);
	kdebug("wasup?");
	pmm_init((u8*)kernel_end, (u8*)(minfo->mem_upper * 1024));
	char *sstr = "hello, world";
	char* buffer = pmm_alloc();
	int i = 0;
	for (char *c = sstr; *c != '\0'; ++c) {
		buffer[i] = sstr[i];
		++i;
	}
	kdebug("this buffer=> %s <= was allocated using pmm_alloc().\n", buffer);
/*	void *a = pmm_alloc();
	void *b = pmm_alloc();
	void *c = pmm_alloc();
	void *d = pmm_alloc();
	void *e = pmm_alloc();
	void *f = pmm_alloc();
	void *g = pmm_alloc();
	pmm_free(buffer);
	void *h = pmm_alloc();
	pmm_free(a);	
	pmm_free(b);	
	pmm_free(c);	
	pmm_free(d);	
	pmm_free(e);	
	pmm_free(f);	
	pmm_free(g);	
	pmm_free(h);*/	
	vmm_setup_kpgdir();
	enable_paging();
	return minfo->mem_lower;
}
