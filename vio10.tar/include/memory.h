#pragma once
#include <defs.h>
#include <x86.h>

void init_segmentation(); /* sets up a Intel Flat Memory Model with segments:
						   * kernel code, kernel data, user code, user data */
struct freelist_t {
	struct freelist_t* next;
};
struct pmm_t {
	u8* start;
	u8* end;
	u32 allocated_pages;
	u32 free_pages;
	struct freelist_t* freelist;
};
typedef struct pmm_t pmm_t;
extern pmm_t pmm;


void pmm_init(u8* start, u8* end);
void* pmm_alloc();
void pmm_free(void* ptr);
u32 page_roundup(u32 x);
pte_t** vmm_setup_kernel(); /* allocates a PD, identity maps the kernel and returns it */ 
/* maps memory from phys_start to phys_start + size, to virtual address virtual_start to
 * virtual_start + size  with permissions(see PTE_* macros) */
void vmm_map(pte_t** pdir, void* phys_start, void* virtual_start, u32 size, u8 permissons);
void vmm_setup_kpgdir(); /* creates a page table for the kernel,
					   *calls vmm_setup_kernel() and loads it in cr3 */ 
