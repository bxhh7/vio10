#pragma once
void* memset(void *src, char c, int size);
