#include <libc/libc.h>
void* memset(void *src, char c, int size) {
	for (int i = 0; i < size; i++) {
		*(char*)(src++) = c;
	}
	return src;
}
